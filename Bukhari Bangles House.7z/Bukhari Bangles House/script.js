let cart = JSON.parse(localStorage.getItem('cart')) || [];
const buttons = document.querySelectorAll('.add-cart');
const cartItemsContainer = document.getElementById('cart-items');
const totalAmountEl = document.getElementById('total-amount');

buttons.forEach(btn => btn.addEventListener('click', e => {
    const id = e.target.dataset.id;
    const existing = cart.find(item=>item.id==id);
    if(existing) existing.qty++;
    else cart.push({id, name: e.target.parentElement.querySelector('h3').innerText, price: parseFloat(e.target.parentElement.querySelector('p').innerText.replace('$','')), qty:1});
    localStorage.setItem('cart', JSON.stringify(cart));
    alert('Added to cart');
}));

function renderCart(){
    if(!cartItemsContainer) return;
    cartItemsContainer.innerHTML = '';
    let total=0;
    cart.forEach(item=>{
        total += item.price*item.qty;
        const div = document.createElement('div');
        div.innerHTML = `<p>${item.name} x${item.qty} - $${(item.price*item.qty).toFixed(2)}</p>`;
        cartItemsContainer.appendChild(div);
    });
    totalAmountEl.innerText = total.toFixed(2);
}

renderCart();
