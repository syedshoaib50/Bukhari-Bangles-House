# Bukhari Choodi House E-Commerce

**E-commerce site** built with Html,CSS and Js Features include:

- Home, About, Shop, Gallery, Contact, Cart, Checkout pages.
- 3D/CSS animation effects on banner and components.
- Shopping cart using js.

## Installation

1. Clone the repo: `git clone https://github.com/syedshoaib50/bukhari-bangles-house.git`
3. Run development server: `chrome , localhost`
4. Open `http://localhost.com` in browser.

## Usage

-To Buy Products with cart.

## License

This project is for demonstration purposes.

